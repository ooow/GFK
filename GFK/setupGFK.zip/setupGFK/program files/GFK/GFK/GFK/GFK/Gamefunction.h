bool used[17];
int mn[25][4];
value struct man {
	int x, y;
};
value struct quest {
	System::String^ text; 
	System::String^ anser; 
};
man Q;